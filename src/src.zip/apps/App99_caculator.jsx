import logo from '../logo.svg';
import './App.css';
import Caculator from '../components/Caculator';

function App() {

  return (
    <div>
     <Caculator />
    </div>
  );
}

export default App;
